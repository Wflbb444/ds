# This package will contain the spiders of your Scrapy project
#
# Please refer to the documentation for information on how to create and manage
# your spiders.
import csv

import requests
import mysql.connector
from lxml import etree
try:
    db=mysql.connector.connect(
    host="localhost",
    port=3306,
    user="root",
    password="zcy200404",
    database="sakila",
    charset='utf8'
    )
    cursor=db.cursor()
except mysql.connector.Error as err:
    print(f"Something went wrong: {err}")

#打开csV文件以写入数据

with open('book_data.csv', 'w', newline='', encoding='utf-8') as fp: 
    writer = csv.writer(fp) 
    #先定义要爬取的字段
    writer.writerow(('name'))
    #定义要爬取的链接及设置header相关参数   
    urls = ['http://category.dangdang.com/pg{}-cp01.54.00.00.00.00.html'.format(str(i)) for i in range(1, 11)]
    headers={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    #通过 request 请求访问网页并获取网页内容

    for url in urls:
        html = requests.get(url, headers=headers)
        selector = etree.HTML(html.text)
        infos = selector.xpath("//ul[@class='bigimg']/li") # visit all the URLS and get information  
        # 解析网页内容

        for info in infos:

            name = info.xpath("//li/p[1]/a/text()")

            #将获取的数据写入CSV文件 
            for i in range(0,len(name)):
                #writer.writerow((name[i]))
                try:
                    sql="""INSERT INTO books (name)VALUES('{}')""".format(str(name[i]))
                    cursor.execute(sql)
                    db.commit()
                except:
                    print('something went wrong',i)

